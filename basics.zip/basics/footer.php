<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        footer{
            background-color:pink;
        }
        a{
            text-decoration: none;
            color: black;
        }
        .item {
            float: left;
            width: 200px;
        }
        .logo{
            float: left;
            width: 230px;
            margin-bottom: 10px;
        }
        h6{
            background:  rgba(128, 128, 128, 0.521);
        }
        
        .container2{
            clear:both;
           
        }

    </style>
</head>
<body>
    
<footer>
    <hr style="margin-top: 30px;"> 
   <div class="container">
   <div class="logo">
    <img src="shoes\shows.png" alt="logo" height=" 180px" width=" 220px">
   <br>
   </div>
        <div class="item">
   
    <ul type="NONE">
        <li> <h5>
    CONTACT US
    </h5></li>
        <li><a href="contact.php">
        Customer Service</a></li>
        <li><a href="about.php">
        ABOUT US </a></li>
        <li><a href="about.php">
        OTHER </a></li>
    </ul>
    </div>
    <div class="item">
    
    <ul type="none">
        <li><h5>
        HELP CENTER
    </h5></li>
        <li><a href="contact.php">
        FAQ</a></li>
        <li><a href="#">
        SHIPING OPTIONS</a></li>
        <li><a href="# ">
        Payment OPTIONS </a></li>
    </ul>
    </div>
    <div class="item">
    
    <ul type="none">
        <li><h5>
        MY ACCOUNT 
    </h5></li>
        <li><a href="reg_form.php">
        MANAGE YOUR ACCOUNT </a></li>
        <li><a href="logout.php">
        LOGOUT</a></li>
        <li><a href="mycart.php ">
        ORDER Status </a></li>
    </ul>
    </div>
    </div>
    
   
</footer>
<div class ="container2">
    <h6 align="center"> &copy;  2014-2024 STYLEMIS. ALL RIGHTS RESERVED </h6> 
    </div>

</body>
</html>